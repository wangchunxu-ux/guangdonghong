// app.js
App({
  onLaunch: function () {
    // 初始化应用
  },
  globalData: {
    userInfo: null,
    apiBase: 'http://localhost:3000' // 模拟服务器URL
  }
})



