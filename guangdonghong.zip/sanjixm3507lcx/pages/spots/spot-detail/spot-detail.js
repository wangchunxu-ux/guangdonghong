// pages/spots/spot-detail/spot-detail.js
Page({
  data: {
    spotId: '',
    spotDetail: {},
    loading: true
  },
  onLoad: function(options) {
    const id = options.id;
    
    this.setData({
      spotId: id
    });
    
    this.getSpotDetail(id);
  },
  getSpotDetail: function(id) {
    // 获取所有景点列表，然后在前端筛选
    wx.request({
      url: getApp().globalData.apiBase + '/locations',
      success: (res) => {
        if (res.statusCode === 200 && Array.isArray(res.data)) {
          // 在返回的数组中查找指定id的景点
          const spot = res.data.find(item => item.id === parseInt(id));
          
          if (spot) {
            this.setData({
              spotDetail: spot,
              loading: false
            });
          } else {
            // 如果找不到，加载模拟数据
            this.loadMockData(id);
          }
        } else {
          // 如果API请求格式不符，加载模拟数据
          this.loadMockData(id);
        }
      },
      fail: () => {
        // 如果API请求出错，加载模拟数据
        this.loadMockData(id);
      }
    });
  },
  loadMockData: function(id) {
    // 模拟数据作为备用
    this.setData({
      spotDetail: {
        id: id,
        name: "红色景点" + id,
        imageUrl: "/images/spot" + id + ".jpg",
        description: "这是一个重要的红色景点，具有深厚的历史意义。",
        address: "广东省某市某区",
        openingHours: "全天开放",
        phone: "020-12345678"
      },
      loading: false
    });
  },
  makePhoneCall: function() {
    if (this.data.spotDetail.phone) {
      wx.makePhoneCall({
        phoneNumber: this.data.spotDetail.phone
      });
    }
  },
  checkin: function() {
    wx.showModal({
      title: '打卡成功',
      content: `您已成功在"${this.data.spotDetail.name}"完成VR打卡，获得5积分！`,
      showCancel: false
    });
  },
  openLocation: function() {
    wx.openLocation({
      latitude: 23.129163,
      longitude: 113.264435,
      name: this.data.spotDetail.name,
      address: this.data.spotDetail.address
    });
  }
})