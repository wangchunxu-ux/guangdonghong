// pages/spots/spots.js
Page({
  data: {
    spots: [],
    venues: [],
    loading: true
  },
  onLoad: function() {
    this.getSpots();
  },
  getSpots: function() {
    // 从API获取所有景点数据
    wx.request({
      url: getApp().globalData.apiBase + '/locations',
      success: (res) => {
        if (res.statusCode === 200) {
          // 成功获取数据，将前4个设为景点，后面的设为场馆
          const allLocations = res.data;
          const spots = allLocations.filter(item => item.id <= 4);
          const venues = allLocations.filter(item => item.id > 4);
          
          this.setData({
            spots: spots,
            venues: venues,
            loading: false
          });
        } else {
          // 使用模拟数据
          this.loadMockData();
        }
      },
      fail: () => {
        // 请求失败，使用模拟数据
        this.loadMockData();
      }
    });
  },
  loadMockData: function() {
    // 模拟数据
    this.setData({
      spots: [
        {
          id: 1,
          name: "松源镇金星村红色村",
          imageUrl: "/images/spot1.jpg"
        },
        {
          id: 2,
          name: "仁居村红色村",
          imageUrl: "/images/spot2.jpg"
        },
        {
          id: 3,
          name: "乌迳古道",
          imageUrl: "/images/spot3.jpg"
        },
        {
          id: 4,
          name: "茶阳镇太宁村红色村",
          imageUrl: "/images/spot4.jpg"
        }
      ],
      venues: [
        {
          id: 5,
          name: "八乡山镇滩良村红色村",
          imageUrl: "/images/spot5.jpg",
          distance: "1960.5km"
        },
        {
          id: 6,
          name: "梅关古道",
          imageUrl: "/images/spot6.jpg",
          distance: "1962.1km"
        }
      ],
      loading: false
    });
  },
  navigateToDetail: function(e) {
    const id = e.currentTarget.dataset.id;
    const name = e.currentTarget.dataset.name;
    wx.navigateTo({
      url: `/pages/spots/spot-detail/spot-detail?id=${id}&name=${name}`
    });
  }
})