// pages/map/map.js
Page({
  data: {
    mapData: {},
    markers: [],
    userStats: {
      points: 7,
      vrCheckins: 0,
      realCheckins: 0
    },
    filters: {
      city: '全部城市',
      type: '全部类型',
      status: '打卡状态'
    },
    // 广东省的经纬度中心点和缩放级别
    longitude: 113.26,
    latitude: 23.13,
    scale: 10,
    // 禁用定位和自动移动
    enableSatellite: false,
    enableBuilding: false,
    showCompass: false,
    enableRotate: false,
    enable3D: false
  },
  onLoad: function () {
    // 1. 显示加载提示 API
    wx.showLoading({
      title: '加载地图中',
      mask: true
    });
    
    // 不再自动加载数据，避免地图移动
    this.setData({
      markers: [
        {
          id: 1,
          latitude: 23.129163,
          longitude: 113.264435,
          iconPath: "/images/gzqy.png",
          width: 30,
          height: 30,
          callout: {
            content: "广州起义纪念馆",
            color: '#e54b44',
            fontSize: 12,
            borderRadius: 4,
            padding: 5,
            display: 'BYCLICK'
          }
        },
        {
          id: 2,
          latitude: 23.125178,
          longitude: 113.280637,
          iconPath: "/images/njs.png",
          width: 30,
          height: 30,
          callout: {
            content: "农讲所纪念馆",
            color: '#e54b44',
            fontSize: 12,
            borderRadius: 4,
            padding: 5,
            display: 'BYCLICK'
          }
        }
      ]
    });
    
    // 隐藏加载提示
    wx.hideLoading();
    
    // 2. 获取位置信息 API (可选，取决于您是否需要用户位置)
    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        console.log('当前位置：', res.latitude, res.longitude);
        // 可以在这里做一些基于位置的操作
      },
      fail: () => {
        console.log('获取位置失败');
      }
    });
    
    // 3. 从本地存储获取之前的筛选设置 API
    wx.getStorage({
      key: 'mapFilters',
      success: (res) => {
        if (res.data) {
          this.setData({
            filters: res.data
          });
        }
      }
    });
  },
  onReady: function() {
    // 4. 创建地图上下文对象 API
    this.mapCtx = wx.createMapContext('guangdongMap');
  },
  showRoute: function () {
    // 5. 显示提示 API
    wx.showToast({
      title: '正在规划打卡线路',
      icon: 'none'
    });
  },
  //点击杠跳转
  navigateToRoute: function() {
    // 6. 页面跳转 API
    wx.navigateTo({
      url: '/pages/route/route'
    });
  },
  filterChange: function (e) {
    const type = e.currentTarget.dataset.type;
    // 7. 显示操作菜单 API
    wx.showActionSheet({
      itemList: ['查看全部', 'VR打卡', '实地打卡'],
      success: (res) => {
        const filters = this.data.filters;
        filters[type] = `选择的选项${res.tapIndex + 1}`;
        this.setData({ filters });
        
        // 8. 将筛选设置保存到本地存储 API
        wx.setStorage({
          key: 'mapFilters',
          data: filters
        });
      }
    });
  },
  // 9. 移动到用户当前位置
  moveToUserLocation: function() {
    // 地图上下文移动到用户位置 API
    this.mapCtx.moveToLocation();
  },
  // 10. 分享功能 API
  onShareAppMessage: function() {
    return {
      title: '探索广东红色地图',
      path: '/pages/map/map',
      imageUrl: '/images/map_share.jpg'
    };
  }
})