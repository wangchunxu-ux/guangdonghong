// pages/profile/checkin-record/checkin-record.js

Page({
  data: {
    activeTab: 0,
    records: []
  },
  onLoad: function() {
    // 可以从服务器获取数据
  },
  handleViewDetail: function(e) {
    const recordId = e.detail.id;
    // 查看打卡详情的逻辑
    wx.showToast({
      title: '查看打卡ID: ' + recordId,
      icon: 'none'
    });
  },
  handleShareRecord: function(e) {
    const { id, name } = e.detail;
    // 分享打卡记录的逻辑
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage']
    });
  },
  switchTab: function(e) {
    const index = e.currentTarget.dataset.index;
    this.setData({
      activeTab: index
    });
  }
})