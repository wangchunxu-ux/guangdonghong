// pages/profile/profile.js
Page({
  data: {
    userInfo: {
      avatarUrl: '',
      nickName: '微信用户',
      level: 'LV1 一鸣惊人',
      id: '3465000'
    },
    userStats: {
      vrCheckins: 0,
      realCheckins: 0,
      quizCount: 0
    }
  },
  onLoad: function () {
    // 代码保持不变
    wx.showLoading({
      title: '加载个人信息',
      mask: true
    });
    
    this.getUserInfo();
    setTimeout(() => {
      this.setData({
        isLoading: false
      });
      wx.hideLoading();
      
      wx.showToast({
        title: '加载成功',
        icon: 'success',
        duration: 1500
      });
    }, 3000);
  },
  
  getUserInfo: function () {
    // 代码保持不变
    wx.request({
      url: getApp().globalData.apiBase + '/user',
      success: (res) => {
        if (res.statusCode === 200) {
          this.setData({
            userInfo: res.data.userInfo,
            userStats: res.data.userStats
          });
          
          wx.hideLoading();
          
          wx.setStorage({
            key: 'userInfo',
            data: res.data.userInfo
          });
        }
      },
      fail: () => {
        wx.hideLoading();
        
        wx.showModal({
          title: '提示',
          content: '获取用户信息失败，请检查网络连接',
          showCancel: false
        });
        
        wx.getStorage({
          key: 'userInfo',
          success: (res) => {
            this.setData({
              userInfo: res.data
            });
          }
        });
      }
    });
  },
  
  // 已有的函数
  viewCheckinRecord: function () {
    console.log('跳转到打卡记录');
    wx.navigateTo({
      url: '/pages/profile/checkin-record/checkin-record'
    });
  },
  
  contactService: function () {
    console.log('拨打客服电话');
    wx.makePhoneCall({
      phoneNumber: '114514'
    });
  },
  
  // 添加缺失的函数
  viewQuizRecord: function() {
    console.log('跳转到答题记录');
    wx.navigateTo({
      url: '/pages/quiz/quiz-record/quiz-record'
    });
  },
  
  viewPoints: function() {
    console.log('查看我的积分');
    wx.showToast({
      title: '积分功能开发中',
      icon: 'none'
    });
  },
  
  viewFavorites: function() {
    console.log('查看我的收藏');
    wx.showToast({
      title: '收藏功能开发中',
      icon: 'none'
    });
  },
  
  viewItinerary: function() {
    console.log('查看我的行程');
    wx.showToast({
      title: '行程功能开发中',
      icon: 'none'
    });
  },
  
  viewExchangeRecord: function() {
    console.log('查看积分兑换记录');
    wx.showToast({
      title: '兑换记录功能开发中',
      icon: 'none'
    });
  },
  
  // 用户ID复制功能(可以添加到用户ID点击事件)
  copyUserId: function() {
    wx.setClipboardData({
      data: this.data.userInfo.id,
      success: () => {
        wx.showToast({
          title: 'ID已复制',
          icon: 'success'
        });
      }
    });
    //
    achievements: [
      {
        id: 1,
        title: "红色足迹",
        icon: "/images/daka.jpg",
        description: "完成10次红色景点打卡",
        progress: 3,
        total: 10,
        completed: false
      },
      {
        id: 2,
        title: "知识达人",
        icon: "/images/dt.jpg",
        description: "完成5次红色知识测试",
        progress: 5,
        total: 5,
        completed: true
      }
    ]
  },
  handleViewAchievement: function(e) {
    const achievementId = e.detail.id;
    wx.showModal({
      title: '成就详情',
      content: '查看成就ID: ' + achievementId,
      showCancel: false
    });
  
  }
})