// pages/quiz/quiz.js
Page({
  data: {
    quizStats: {
      todayCount: 0,
      totalCount: 0,
      correctCount: 0
    },
    ranking: [],
    rules: '每日登录可参与红色知识答题，答对题目可获得积分奖励。', // 默认规则
    userRanking: {
      rank: 0,
      score: 0,
      totalUsers: 0
    }
  },
  onLoad: function () {
    this.getQuizData();
    this.getQuizRules();
    this.getUserRanking();
  },
  getQuizData: function () {
    wx.request({
      url: getApp().globalData.apiBase + '/quiz',
      success: (res) => {
        if (res.statusCode === 200) {
          this.setData({
            quizStats: res.data.quizStats,
            ranking: res.data.ranking
          });
        }
      },
      fail: () => {
        console.log('获取答题数据失败，使用默认数据');
      }
    });
  },
  getQuizRules: function () {
    wx.request({
      url: getApp().globalData.apiBase + '/quiz-rules',
      success: (res) => {
        if (res.statusCode === 200 && res.data && res.data.rules) {
          this.setData({
            rules: res.data.rules
          });
        }
      },
      fail: (err) => {
        console.log('获取规则失败，使用默认规则', err);
      }
    });
  },
  getUserRanking: function () {
    const token = wx.getStorageSync('token');
    wx.request({
      url: getApp().globalData.apiBase + '/quiz-user-ranking',
      header: {
        'content-type': 'application/json',
        'Authorization': token || ''
      },
      success: (res) => {
        if (res.statusCode === 200 && res.data) {
          this.setData({
            userRanking: res.data
          });
        }
      },
      fail: (err) => {
        console.log('获取用户排名失败，使用默认数据', err);
      }
    });
  },
  startQuiz: function () {
    wx.navigateTo({
      url: '/pages/quiz/quiz-detail/quiz-detail'
    });
  },
  viewQuizRecord: function () {
    wx.navigateTo({
      url: '/pages/quiz/quiz-record/quiz-record'
    });
  },
  showRules: function () {
    wx.showModal({
      title: '活动规则',
      content: this.data.rules,
      showCancel: false
    });
  },
  // 【新增】点击排行榜分数跳转（或弹提示）
  goToRankingPage: function () {
    wx.showToast({
      title: '即将跳转排行榜页',
      icon: 'none'
    });
    // 未来如果有排行榜页面，可以打开下面这行
    // wx.navigateTo({
    //   url: '/pages/quiz/quiz-ranking/quiz-ranking'
    // });
  },
  // 【新增】反馈按钮
  sendFeedback: function () {
    wx.showModal({
      title: '反馈',
      content: '如有问题，请联系管理员或填写反馈表单～',
      confirmText: '知道了',
      showCancel: false
    });
    quizzes: [
      {
        id: 1,
        type: "党史知识",
        difficulty: "初级",
        title: "中国共产党成立历史",
        questionCount: 10,
        timeLimit: 15,
        points: 100
      },
      {
        id: 2,
        type: "革命历史",
        difficulty: "中级",
        title: "长征路线与重要事件",
        questionCount: 15,
        timeLimit: 20,
        points: 150
      }
    ]
  },
  handleStartQuiz: function(e) {
    const quizId = e.detail.id;
    wx.navigateTo({
      url: '/pages/quiz/quiz-detail/quiz-detail?id=' + quizId
    });
  
  }
})
