Page({
  data: {
     // 页面数据
    spots: [
      {
        id: 1,
        name: "松源镇金星村红色村",
        image: "/images/spot1.jpg",
        distance: "1949.1km",
        openTime: "全天开放",
        address: "广东省梅州市梅县区松源镇金星村"
      },
      {
        id: 2,
        name: "仁居村红色村",
        image: "/images/spot2.jpg",
        distance: "1957.5km",
        openTime: "全天开放",
        address: "广东省梅州市平远县仁居镇仁居村"
      },
      {
        id: 3,
        name: "乌迳古道",
        image: "/images/spot3.jpg",
        distance: "1957.7km",
        openTime: "全天开放",
        address: "广东省韶关市南雄市乌迳镇",
        isVR: true
      }
    ]
  },
  
  // 在线参观
  onlineVisit: function(e) {
    const id = e.currentTarget.dataset.id;
    wx.showToast({
      title: '在线参观功能开发中',
      icon: 'none'
    });
  },
  
  // 实地打卡
  offlineCheckin: function(e) {
    const id = e.currentTarget.dataset.id;
    wx.showToast({
      title: '实地打卡功能开发中',
      icon: 'none'
    });
  },
  
  // 查看景点详情
  viewSpotDetail: function(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '/pages/spots/spot-detail/spot-detail?id=' + id
    });
  }
})