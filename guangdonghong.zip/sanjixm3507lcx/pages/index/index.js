// pages/index/index.js
Page({
  data: {
    bannerInfo: {},
    menuItems: [],
    recommendItems: [],
    location: {
      latitude: '',
      longitude: '',
      hasLocation: false
    },
    featuredSpots: [
      {
        id: 1,
        name: "井冈山革命博物馆",
        imageUrl: "/images/spot1.jpg",
        description: "中国革命的摇篮，红色旅游胜地",
        address: "江西省吉安市井冈山市",
        tag: "革命历史"
      },
      {
        id: 2,
        name: "西柏坡纪念馆",
        imageUrl: "/images/spot2.jpg",
        description: "中共中央所在地，新中国的奠基地",
        address: "河北省石家庄市平山县",
        tag: "党史教育"
      }
    ],
    nearbySpots: [
      {
        id: 3,
        name: "广东革命历史博物馆",
        imageUrl: "/images/spot3.jpg",
        description: "展示广东革命历史的重要场所",
        address: "广东省广州市越秀区",
        openingHours: "9:00-17:00"
      },
      {
        id: 4,
        name: "黄花岗七十二烈士陵园",
        imageUrl: "/images/spot4.jpg",
        description: "纪念辛亥革命先烈的陵园",
        address: "广东省广州市越秀区",
        openingHours: "8:30-17:30"
      }
    ]
  },
  onLoad: function () {
    this.getHomeData();
    
    // 4. 获取系统信息 API
    wx.getSystemInfo({
      success: (res) => {
        console.log('设备信息：', res);
        // 显示设备信息提示
        wx.showToast({
          title: '已获取设备信息',
          icon: 'success',
          duration: 1500
        });
      }
    });
    
    // 5. 获取当前位置 API - 先授权再获取
    this.getLocationWithAuth();
  },
  
  // 获取位置信息（带授权）
  getLocationWithAuth: function() {
    wx.showLoading({
      title: '获取位置中',
    });
    
    // 先检查是否有定位权限
    wx.getSetting({
      success: (res) => {
        if (res.authSetting['scope.userLocation'] === false) {
          // 用户曾经拒绝过授权，需要引导用户打开授权
          wx.hideLoading();
          wx.showModal({
            title: '需要位置权限',
            content: '请授权小程序获取位置信息，以便提供更好的服务',
            confirmText: '去授权',
            success: (modalRes) => {
              if (modalRes.confirm) {
                wx.openSetting({
                  success: (settingRes) => {
                    if (settingRes.authSetting['scope.userLocation']) {
                      // 用户在设置页面中打开了定位权限
                      this.getLocation();
                    }
                  }
                });
              }
            }
          });
        } else {
          // 未拒绝过或已授权，直接获取位置
          this.getLocation();
        }
      },
      complete: () => {
        wx.hideLoading();
      }
    });
  },
  
  // 获取位置信息
  getLocation: function() {
    wx.showLoading({
      title: '定位中...',
    });
    
    wx.getLocation({
      type: 'wgs84',
      success: (res) => {
        const latitude = res.latitude;
        const longitude = res.longitude;
        
        // 更新页面数据
        this.setData({
          'location.latitude': latitude.toFixed(6),
          'location.longitude': longitude.toFixed(6),
          'location.hasLocation': true
        });
        
        // 显示成功提示
        wx.showToast({
          title: '位置获取成功',
          icon: 'success',
          duration: 1500
        });
      },
      fail: (err) => {
        console.log('获取位置失败', err);
        wx.showToast({
          title: '位置获取失败',
          icon: 'none',
          duration: 2000
        });
      },
      complete: () => {
        wx.hideLoading();
      }
    });
  },
  getHomeData: function () {
    // 1. 显示加载中 API
    wx.showLoading({
      title: '加载中',
    });
    
    // 2. 网络请求 API
    wx.request({
      url: getApp().globalData.apiBase + '/home',
      success: (res) => {
        if (res.statusCode === 200) {
          this.setData({
            bannerInfo: res.data.bannerInfo,
            menuItems: res.data.menuItems,
            recommendItems: res.data.recommendItems
          });
          
          // 6. 存储数据到本地 API
          wx.setStorage({
            key: 'recommendItems',
            data: res.data.recommendItems
          });
        }
      },
      complete: () => {
        // 隐藏加载中
        wx.hideLoading();
      }
    });
  },
  navigateToDetail: function (e) {
    const id = e.currentTarget.dataset.id;
    // 判断点击的是什么类型的菜单项，这里简化处理
    if (id === 3 || id === 4) { // 线下展览或场馆推介
      // 3. 页面跳转 API
      wx.navigateTo({
        url: '/pages/spots/spots'
      });
    } else {
      // 7. 显示提示 API
      wx.showToast({
        title: '功能正在开发中',
        icon: 'none'
      });
    }
  },
  // 8. 分享功能 API
  onShareAppMessage: function () {
    return {
      title: '打卡广东红',
      path: '/pages/index/index',
      imageUrl: '/images/share.jpg'
    };
  },
  // 9. 预览图片 API
  previewBannerImage: function () {
    wx.previewImage({
      current: this.data.bannerInfo.imageUrl,
      urls: [this.data.bannerInfo.imageUrl]
    });
    // 预览图片完成
  },
  handleViewSpotDetail: function(e) {
    const spotId = e.detail.id;
    wx.navigateTo({
      url: '/pages/spots/spot-detail/spot-detail?id=' + spotId
    });
  },
  handlePreviewImage: function(e) {
    const { current, urls } = e.detail;
    wx.previewImage({
      current,
      urls
    });
  },
  
  // 处理景点打卡事件
  handleSpotCheckin: function(e) {
    const { id, name, type } = e.detail;
    wx.showModal({
      title: '打卡确认',
      content: `确定要在${name}进行${type}打卡吗？`,
      success: (res) => {
        if (res.confirm) {
          wx.showToast({
            title: '打卡成功',
            icon: 'success'
          });
          // 这里可以添加实际的打卡逻辑
        }
      }
    });
  },
  
  // 处理景点展开/收起事件
  handleSpotToggle: function(e) {
    const { id, expanded, index } = e.detail;
    console.log(`景点${id}已${expanded ? '展开' : '收起'}，索引：${index}`);
    // 可以在这里添加其他逻辑
  }
});