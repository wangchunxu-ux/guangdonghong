// components/achievement-card/achievement-card.js
Component({
  properties: {
    achievementInfo: {
      type: Object,
      value: {}
    }
  },
  data: {
    // 内部数据
  },
  methods: {
    viewDetail: function() {
      // 查看成就详情
      this.triggerEvent('viewDetail', {
        id: this.properties.achievementInfo.id
      });
    }
  }
})