// components/checkin-item/checkin-item.js
Component({
  properties: {
    recordInfo: {
      type: Object,
      value: {}
    },
    index: {
      type: Number,
      value: 0
    }
  },
  data: {
    // 内部数据
    formattedDate: ''
  },
  lifetimes: {
    attached: function() {
      // 在组件实例进入页面节点树时执行
      if (this.properties.recordInfo.date) {
        this.formatDate(this.properties.recordInfo.date);
      }
    }
  },
  methods: {
    formatDate: function(dateStr) {
      // 格式化日期显示
      const date = new Date(dateStr);
      const year = date.getFullYear();
      const month = (date.getMonth() + 1).toString().padStart(2, '0');
      const day = date.getDate().toString().padStart(2, '0');
      const hours = date.getHours().toString().padStart(2, '0');
      const minutes = date.getMinutes().toString().padStart(2, '0');
      
      this.setData({
        formattedDate: `${year}-${month}-${day} ${hours}:${minutes}`
      });
    },
    viewDetail: function() {
      // 查看打卡详情
      this.triggerEvent('viewDetail', {
        id: this.properties.recordInfo.id
      });
    },
    shareRecord: function() {
      // 分享打卡记录
      this.triggerEvent('shareRecord', {
        id: this.properties.recordInfo.id,
        name: this.properties.recordInfo.spotName
      });
    }
  }
})