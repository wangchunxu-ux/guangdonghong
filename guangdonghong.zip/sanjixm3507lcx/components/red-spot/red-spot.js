// components/red-spot/red-spot.js
Component({
  properties: {
    spotInfo: {
      type: Object,
      value: {}
    },
    index: {
      type: Number,
      value: 0
    }
  },
  data: {
    isExpanded: false
  },
  methods: {
    toggleExpand: function() {
      this.setData({
        isExpanded: !this.data.isExpanded
      });
      // 向父组件传递事件
      this.triggerEvent('toggle', { 
        id: this.properties.spotInfo.id,
        expanded: !this.data.isExpanded,
        index: this.properties.index
      });
    },
    navigateToDetail: function() {
      // 向父组件传递事件
      this.triggerEvent('navigate', { 
        id: this.properties.spotInfo.id,
        name: this.properties.spotInfo.name
      });
    },
    checkin: function() {
      // 向父组件传递事件
      this.triggerEvent('checkin', { 
        id: this.properties.spotInfo.id,
        name: this.properties.spotInfo.name,
        type: 'VR'
      });
    }
  }
})