// components/quiz-card/quiz-card.js
Component({
  properties: {
    quizInfo: {
      type: Object,
      value: {}
    }
  },
  data: {
    // 内部数据
  },
  methods: {
    startQuiz: function() {
      // 开始答题
      this.triggerEvent('startQuiz', {
        id: this.properties.quizInfo.id,
        type: this.properties.quizInfo.type
      });
    }
  }
})















