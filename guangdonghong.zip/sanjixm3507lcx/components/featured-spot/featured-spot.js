// components/featured-spot/featured-spot.js
Component({
  properties: {
    spotInfo: {
      type: Object,
      value: {}
    }
  },
  data: {
    // 内部数据
  },
  methods: {
    navigateToDetail: function() {
      // 跳转到景点详情
      this.triggerEvent('navigate', {
        id: this.properties.spotInfo.id,
        name: this.properties.spotInfo.name
      });
    },
    previewImage: function() {
      // 预览图片
      wx.previewImage({
        current: this.properties.spotInfo.imageUrl,
        urls: [this.properties.spotInfo.imageUrl]
      });
    }
  }
})